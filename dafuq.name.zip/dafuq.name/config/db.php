<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=tasksdb',
    'username' => 'root',
    'password' => '12345',
    'charset' => 'utf8',
];
