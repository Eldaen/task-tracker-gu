<?php

use yii\db\Migration;

/**
 * Class m171125_084905_deploy_migration
 */
class m171125_084905_deploy_migration extends Migration
{
    /**
     * @inheritdoc
     */
    public function safeUp()
    {
        $tables = Yii::$app->db->schema->getTableNames();
        $dbType = 'mysql';
        $tableOptions_mysql = "CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB";
        $tableOptions_mssql = "";
        $tableOptions_pgsql = "";
        $tableOptions_sqlite = "";
        /* MYSQL */
        if (!in_array('auth_assignment', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%auth_assignment}}', [
                    'item_name' => 'VARCHAR(64) NOT NULL',
                    0 => 'PRIMARY KEY (`item_name`)',
                    'user_id' => 'VARCHAR(64) NOT NULL',
                    1 => 'PRIMARY KEY (`user_id`)',
                    'created_at' => 'INT(11) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('auth_item', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%auth_item}}', [
                    'name' => 'VARCHAR(64) NOT NULL',
                    0 => 'PRIMARY KEY (`name`)',
                    'type' => 'SMALLINT(6) NOT NULL',
                    'description' => 'TEXT NULL',
                    'rule_name' => 'VARCHAR(64) NULL',
                    'data' => 'BLOB NULL',
                    'created_at' => 'INT(11) NULL',
                    'updated_at' => 'INT(11) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('auth_item_child', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%auth_item_child}}', [
                    'parent' => 'VARCHAR(64) NOT NULL',
                    0 => 'PRIMARY KEY (`parent`)',
                    'child' => 'VARCHAR(64) NOT NULL',
                    1 => 'PRIMARY KEY (`child`)',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('auth_rule', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%auth_rule}}', [
                    'name' => 'VARCHAR(64) NOT NULL',
                    0 => 'PRIMARY KEY (`name`)',
                    'data' => 'BLOB NULL',
                    'created_at' => 'INT(11) NULL',
                    'updated_at' => 'INT(11) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('menu', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%menu}}', [
                    'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id`)',
                    'name' => 'VARCHAR(128) NOT NULL',
                    'parent' => 'INT(11) NULL',
                    'route' => 'VARCHAR(255) NULL',
                    'order' => 'INT(11) NULL',
                    'data' => 'BLOB NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('tasks', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%tasks}}', [
                    'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id`)',
                    'title' => 'VARCHAR(255) NOT NULL',
                    'body' => 'TEXT NOT NULL',
                    'status' => 'INT(11) NULL',
                    'creator_id' => 'INT(11) NOT NULL',
                    'created_at' => 'INT(11) NOT NULL',
                    'updated_at' => 'INT(11) NOT NULL',
                    'deadline' => 'INT(11) NOT NULL',
                    'completion_time' => 'INT(11) NULL',
                    'team_id' => 'INT(11) NOT NULL',
                    'executor_id' => 'INT(11) NULL',
                    'completion_message' => 'VARCHAR(255) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('team_binds', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%team_binds}}', [
                    'team_id' => 'INT(11) NOT NULL',
                    0 => 'PRIMARY KEY (`team_id`)',
                    'user_id' => 'INT(11) NOT NULL',
                    1 => 'PRIMARY KEY (`user_id`)',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('teams', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%teams}}', [
                    'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id`)',
                    'name' => 'VARCHAR(45) NOT NULL',
                    'description' => 'TEXT NOT NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('telegram_event', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%telegram_event}}', [
                    'id_telegram_event' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id_telegram_event`)',
                    'telegram_event_name' => 'VARCHAR(50) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('telegram_message', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%telegram_message}}', [
                    'id_telegram_message' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id_telegram_message`)',
                    'id_telegram_user' => 'INT(11) NULL',
                    'is_proceeded' => 'TINYINT(1) NULL',
                    'timestamp_proceed' => 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('telegram_offset', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%telegram_offset}}', [
                    'id_offset' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id_offset`)',
                    'timestamp_offset' => 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('telegram_subscribe', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%telegram_subscribe}}', [
                    'id_telegram_subscription' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id_telegram_subscription`)',
                    'id_user' => 'INT(11) NULL',
                    'id_telegram_user' => 'INT(11) NULL',
                    'id_event' => 'INT(11) NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('user', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%user}}', [
                    'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id`)',
                    'username' => 'VARCHAR(32) NOT NULL',
                    'auth_key' => 'VARCHAR(32) NOT NULL',
                    'password_hash' => 'VARCHAR(255) NOT NULL',
                    'password_reset_token' => 'VARCHAR(255) NULL',
                    'email' => 'VARCHAR(255) NOT NULL',
                    'status' => 'SMALLINT(6) NOT NULL DEFAULT \'10\'',
                    'created_at' => 'INT(11) NOT NULL',
                    'updated_at' => 'INT(11) NOT NULL',
                ], $tableOptions_mysql);
            }
        }

        /* MYSQL */
        if (!in_array('users', $tables))  {
            if ($dbType == "mysql") {
                $this->createTable('{{%users}}', [
                    'id' => 'INT(11) NOT NULL AUTO_INCREMENT',
                    0 => 'PRIMARY KEY (`id`)',
                    'username' => 'VARCHAR(255) NOT NULL',
                    'auth_key' => 'VARCHAR(32) NOT NULL',
                    'password_hash' => 'VARCHAR(255) NOT NULL',
                    'password_reset_token' => 'VARCHAR(255) NULL',
                    'email' => 'VARCHAR(255) NOT NULL',
                    'avatar' => 'VARCHAR(255) NULL',
                    'status' => 'SMALLINT(6) NOT NULL DEFAULT \'10\'',
                    'created_at' => 'INT(11) NOT NULL',
                    'updated_at' => 'INT(11) NOT NULL',
                ], $tableOptions_mysql);
            }
        }


        $this->createIndex('idx_user_id_4638_00','auth_assignment','user_id',0);
        $this->createIndex('idx_rule_name_4658_01','auth_item','rule_name',0);
        $this->createIndex('idx_type_4658_02','auth_item','type',0);
        $this->createIndex('idx_child_4678_03','auth_item_child','child',0);
        $this->createIndex('idx_parent_4758_04','menu','parent',0);
        $this->createIndex('idx_creator_id_4798_05','tasks','creator_id',0);
        $this->createIndex('idx_team_id_4798_06','tasks','team_id',0);
        $this->createIndex('idx_executor_id_4798_07','tasks','executor_id',0);
        $this->createIndex('idx_user_id_4818_08','team_binds','user_id',0);
        $this->createIndex('idx_UNIQUE_username_5118_09','users','username',1);
        $this->createIndex('idx_UNIQUE_email_5118_10','users','email',1);
        $this->createIndex('idx_UNIQUE_password_reset_token_5118_11','users','password_reset_token',1);

        $this->execute('SET foreign_key_checks = 0');
        $this->addForeignKey('fk_auth_item_4628_00','{{%auth_assignment}}', 'item_name', '{{%auth_item}}', 'name', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_auth_rule_4658_01','{{%auth_item}}', 'rule_name', '{{%auth_rule}}', 'name', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_auth_item_4678_02','{{%auth_item_child}}', 'parent', '{{%auth_item}}', 'name', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_auth_item_4678_03','{{%auth_item_child}}', 'child', '{{%auth_item}}', 'name', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_menu_4758_04','{{%menu}}', 'parent', '{{%menu}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_users_4798_05','{{%tasks}}', 'creator_id', '{{%users}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_users_4798_06','{{%tasks}}', 'executor_id', '{{%users}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_teams_4798_07','{{%tasks}}', 'team_id', '{{%teams}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_teams_4818_08','{{%team_binds}}', 'team_id', '{{%teams}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->addForeignKey('fk_users_4818_09','{{%team_binds}}', 'user_id', '{{%users}}', 'id', 'CASCADE', 'NO ACTION' );
        $this->execute('SET foreign_key_checks = 1;');

        $this->execute('SET foreign_key_checks = 0');
        $this->insert('{{%auth_assignment}}',['item_name'=>'Admin','user_id'=>'1','created_at'=>'1510849599']);
        $this->insert('{{%auth_assignment}}',['item_name'=>'BasicUser','user_id'=>'1','created_at'=>'1510911006']);
        $this->insert('{{%auth_assignment}}',['item_name'=>'BasicUser','user_id'=>'2','created_at'=>'1510914094']);
        $this->insert('{{%auth_assignment}}',['item_name'=>'TaskDetailedView','user_id'=>'2','created_at'=>'1510922239']);
        $this->insert('{{%auth_item}}',['name'=>'/admin/*','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1510849287','updated_at'=>'1510849287']);
        $this->insert('{{%auth_item}}',['name'=>'/bot/*','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1511443405','updated_at'=>'1511443405']);
        $this->insert('{{%auth_item}}',['name'=>'/rbac/*','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1510849283','updated_at'=>'1510849283']);
        $this->insert('{{%auth_item}}',['name'=>'/tasks/*','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1510910931','updated_at'=>'1510910931']);
        $this->insert('{{%auth_item}}',['name'=>'/tasks/index','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1510922431','updated_at'=>'1510922431']);
        $this->insert('{{%auth_item}}',['name'=>'/tasks/test','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1511442558','updated_at'=>'1511442558']);
        $this->insert('{{%auth_item}}',['name'=>'/tasks/view','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1510922429','updated_at'=>'1510922429']);
        $this->insert('{{%auth_item}}',['name'=>'/team/*','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1511038116','updated_at'=>'1511038116']);
        $this->insert('{{%auth_item}}',['name'=>'/team/index','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1511034761','updated_at'=>'1511034761']);
        $this->insert('{{%auth_item}}',['name'=>'/team/view','type'=>'2','description'=>'','rule_name'=>'','data'=>'','created_at'=>'1511037927','updated_at'=>'1511037927']);
        $this->insert('{{%auth_item}}',['name'=>'Admin','type'=>'1','description'=>'Администратор всея приложения','rule_name'=>'','data'=>'','created_at'=>'1510849517','updated_at'=>'1510849517']);
        $this->insert('{{%auth_item}}',['name'=>'AdminPanelAccess','type'=>'2','description'=>'Доступ к просмотру админ панели и модуля RBAC','rule_name'=>'','data'=>'','created_at'=>'1510849383','updated_at'=>'1510849401']);
        $this->insert('{{%auth_item}}',['name'=>'BasicUser','type'=>'1','description'=>'Обычный пользователь','rule_name'=>'','data'=>'','created_at'=>'1510910985','updated_at'=>'1510910985']);
        $this->insert('{{%auth_item}}',['name'=>'CanSeeOwnTeams','type'=>'2','description'=>'Возможность видеть к каким командам принадлежит','rule_name'=>'','data'=>'','created_at'=>'1511034749','updated_at'=>'1511034768']);
        $this->insert('{{%auth_item}}',['name'=>'CanSeeTasks','type'=>'2','description'=>'Пользователь может смотреть свои таски','rule_name'=>'','data'=>'','created_at'=>'1510910956','updated_at'=>'1510910956']);
        $this->insert('{{%auth_item}}',['name'=>'TaskDetailedView','type'=>'2','description'=>'Пользователь может открывать подробный просмотр таска','rule_name'=>'сanSeeOwnTasks','data'=>'','created_at'=>'1510913808','updated_at'=>'1510913808']);
        $this->insert('{{%auth_item}}',['name'=>'TeamDetailedView','type'=>'2','description'=>'Пользователь может увидеть страницу подробного просмотра команды.','rule_name'=>'CanSeeOwnTeams','data'=>'','created_at'=>'1511037914','updated_at'=>'1511037914']);
        $this->insert('{{%auth_item_child}}',['parent'=>'AdminPanelAccess','child'=>'/admin/*']);
        $this->insert('{{%auth_item_child}}',['parent'=>'Admin','child'=>'/bot/*']);
        $this->insert('{{%auth_item_child}}',['parent'=>'AdminPanelAccess','child'=>'/rbac/*']);
        $this->insert('{{%auth_item_child}}',['parent'=>'Admin','child'=>'/tasks/*']);
        $this->insert('{{%auth_item_child}}',['parent'=>'CanSeeTasks','child'=>'/tasks/index']);
        $this->insert('{{%auth_item_child}}',['parent'=>'TaskDetailedView','child'=>'/tasks/view']);
        $this->insert('{{%auth_item_child}}',['parent'=>'Admin','child'=>'/team/*']);
        $this->insert('{{%auth_item_child}}',['parent'=>'CanSeeOwnTeams','child'=>'/team/index']);
        $this->insert('{{%auth_item_child}}',['parent'=>'TeamDetailedView','child'=>'/team/view']);
        $this->insert('{{%auth_item_child}}',['parent'=>'Admin','child'=>'AdminPanelAccess']);
        $this->insert('{{%auth_item_child}}',['parent'=>'Admin','child'=>'BasicUser']);
        $this->insert('{{%auth_item_child}}',['parent'=>'BasicUser','child'=>'CanSeeOwnTeams']);
        $this->insert('{{%auth_item_child}}',['parent'=>'BasicUser','child'=>'CanSeeTasks']);
        $this->insert('{{%auth_item_child}}',['parent'=>'BasicUser','child'=>'TaskDetailedView']);
        $this->insert('{{%auth_item_child}}',['parent'=>'BasicUser','child'=>'TeamDetailedView']);
        $this->insert('{{%auth_rule}}',['name'=>'CanSeeOwnTeams','data'=>'O:22:\"app\\rbac\\TeamBoundRule\":3:{s:4:\"name\";s:14:\"CanSeeOwnTeams\";s:9:\"createdAt\";i:1511037854;s:9:\"updatedAt\";i:1511037854;}','created_at'=>'1511037854','updated_at'=>'1511037854']);
        $this->insert('{{%auth_rule}}',['name'=>'сanSeeOwnTasks','data'=>'O:21:\"app\\rbac\\ExecutorRule\":3:{s:4:\"name\";s:15:\"сanSeeOwnTasks\";s:9:\"createdAt\";i:1510913688;s:9:\"updatedAt\";i:1510921985;}','created_at'=>'1510913688','updated_at'=>'1510921985']);
        $this->insert('{{%tasks}}',['id'=>'1','title'=>'Тестовое задание','body'=>'Необходимо протестировать создание и обновление заданий','status'=>'1','creator_id'=>'1','created_at'=>'1510601701','updated_at'=>'1510945923','deadline'=>'1510261200','completion_time'=>'1510945923','team_id'=>'1','executor_id'=>'1','completion_message'=>'asdasd']);
        $this->insert('{{%tasks}}',['id'=>'4','title'=>'Второе тестовое задание','body'=>'Нужно для вывода списка тестовых заданий','status'=>'1','creator_id'=>'1','created_at'=>'1510611970','updated_at'=>'1510945945','deadline'=>'1511384400','completion_time'=>'1510945945','team_id'=>'2','executor_id'=>'1','completion_message'=>'asdasd']);
        $this->insert('{{%tasks}}',['id'=>'5','title'=>'Третьи задание, просроченное','body'=>'чтобы было видно, как помечаются просроченные задания','status'=>'1','creator_id'=>'1','created_at'=>'1510612030','updated_at'=>'1510612030','deadline'=>'1508446800','completion_time'=>'','team_id'=>'1','executor_id'=>'2','completion_message'=>'']);
        $this->insert('{{%tasks}}',['id'=>'6','title'=>'Четвёртое задание','body'=>'Это задание выполнено, оно нужно для демонстрации выполненных заданий','status'=>'0','creator_id'=>'1','created_at'=>'1510674245','updated_at'=>'1510674245','deadline'=>'1510779600','completion_time'=>'','team_id'=>'2','executor_id'=>'','completion_message'=>'']);
        $this->insert('{{%tasks}}',['id'=>'11','title'=>'Телеграм тест','body'=>'Вот тебе задача, тов. админ: Сделай так, чтобы телеграмм бот оповещал всё нормально, да чтобы по скорее!','status'=>'1','creator_id'=>'1','created_at'=>'1511553767','updated_at'=>'1511553767','deadline'=>'1511989200','completion_time'=>'','team_id'=>'1','executor_id'=>'1','completion_message'=>'']);
        $this->insert('{{%tasks}}',['id'=>'12','title'=>'Телеграм тест неподписанному','body'=>'Вот поставлю я сейчас задачу пользователю, который не подписан на обновления в телеграм - не должно ничего плохого случаться.','status'=>'1','creator_id'=>'1','created_at'=>'1511553918','updated_at'=>'1511553918','deadline'=>'1511989200','completion_time'=>'','team_id'=>'1','executor_id'=>'2','completion_message'=>'']);
        $this->insert('{{%team_binds}}',['team_id'=>'1','user_id'=>'1']);
        $this->insert('{{%team_binds}}',['team_id'=>'2','user_id'=>'1']);
        $this->insert('{{%team_binds}}',['team_id'=>'1','user_id'=>'2']);
        $this->insert('{{%teams}}',['id'=>'1','name'=>'Первая команда','description'=>'Ребята, которые рабаотают над Frontend-ом, очень стараются.']);
        $this->insert('{{%teams}}',['id'=>'2','name'=>'Вторая команда','description'=>'Тут дела Backend-ные, всё важно и по взрослому.']);
        $this->insert('{{%telegram_offset}}',['id_offset'=>'614666661','timestamp_offset'=>'2017-11-24 21:20:33']);
        $this->insert('{{%telegram_offset}}',['id_offset'=>'614666662','timestamp_offset'=>'2017-11-24 21:20:54']);
        $this->insert('{{%telegram_offset}}',['id_offset'=>'614666663','timestamp_offset'=>'2017-11-24 21:21:43']);
        $this->insert('{{%telegram_offset}}',['id_offset'=>'614666664','timestamp_offset'=>'2017-11-24 22:29:08']);
        $this->insert('{{%telegram_offset}}',['id_offset'=>'614666665','timestamp_offset'=>'2017-11-24 22:30:40']);
        $this->insert('{{%telegram_subscribe}}',['id_telegram_subscription'=>'0','id_user'=>'0','id_telegram_user'=>'0','id_event'=>'']);
        $this->insert('{{%telegram_subscribe}}',['id_telegram_subscription'=>'2','id_user'=>'1','id_telegram_user'=>'250867313','id_event'=>'']);
        $this->insert('{{%users}}',['id'=>'1','username'=>'Test','auth_key'=>'uTWrSmpJz5cFLGGtyxdd-2s-KrxLlsXj','password_hash'=>'$2y$13$1MkwMQqPjmQHcXBmOL0IxuWNKYJ4G8M0KepGkfLvuAWi9RTOS6H/m','password_reset_token'=>'','email'=>'test@test.test','avatar'=>'','status'=>'10','created_at'=>'1510600590','updated_at'=>'1510600590']);
        $this->insert('{{%users}}',['id'=>'2','username'=>'basic','auth_key'=>'P67pnIEFeu5z_KjOYyPfiY8FwtIWIALN','password_hash'=>'$2y$13$TV55pxSCZU29E.Til1uJluP.E/sDgPE5k19LldXp8DfZqXjQdxEym','password_reset_token'=>'','email'=>'basic@test.test','avatar'=>'','status'=>'10','created_at'=>'1510914066','updated_at'=>'1510914066']);
        $this->execute('SET foreign_key_checks = 1;');
    }

    /**
     * @inheritdoc
     */
    public function safeDown()
    {
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `auth_assignment`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `auth_item`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `auth_item_child`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `auth_rule`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `menu`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `tasks`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `team_binds`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `teams`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `telegram_event`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `telegram_message`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `telegram_offset`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `telegram_subscribe`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `user`');
        $this->execute('SET foreign_key_checks = 1;');
        $this->execute('SET foreign_key_checks = 0');
        $this->execute('DROP TABLE IF EXISTS `users`');
        $this->execute('SET foreign_key_checks = 1;');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m171125_084905_deploy_migration cannot be reverted.\n";

        return false;
    }
    */
}
